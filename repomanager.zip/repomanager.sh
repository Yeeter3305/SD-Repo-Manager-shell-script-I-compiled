# Command 1
curl -LsSf https://astral.sh/uv/install.sh | sh

# Command 2
git clone https://github.com/waylaidwanderer/steam-deck-repo-manager
cd steam-deck-repo-manager

# Command 3
uv run python -m src.main
