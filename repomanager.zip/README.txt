This is a shell script for the Steam Deck Repo Manager by waylaidwanderer. This is not my code. The original repository can be found at https://github.com/waylaidwanderer/steam-deck-repo-manager

This shell script functions as both a launcher and installer. The only files this can download is the repo manager. I do not usually make apps for anything, as I don't know how to (I'm too lazy to learn how) but I decided to make this to make using the manager easier.

To run the manager, open Konsole and type [bash repomanager.sh] If you have not yet installed the manager, this will install and run it. If you have, it will just run it.
